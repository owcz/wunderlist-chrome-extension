# How to install

* Clone this repository (or download the .zip)
* Open chrome://chrome/extensions/ in Chrome
* Enable **Developer Mode**
* **Load unpacked extension** and select the chrome extension
* That's it!