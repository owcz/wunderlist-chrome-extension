browser-extension-common
========================

code shared between various browser extensions
